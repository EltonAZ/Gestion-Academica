package com.colegio.colegio.controller;

import com.colegio.colegio.entity.Curso;
import com.colegio.colegio.entity.Estudiante;
import com.colegio.colegio.entity.Nota;
import com.colegio.colegio.repository.CursoRepository;
import com.colegio.colegio.repository.EstudianteRepository;
import com.colegio.colegio.repository.NotaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/notas")
@CrossOrigin(origins = "*")
public class NotaController {
    @Autowired
    private NotaRepository notaRepo;

    @Autowired
    private EstudianteRepository estudianteRepo;

    @Autowired
    private CursoRepository cursoRepo;

    // Registrar notas (3 + promedio)
    @PostMapping
    public Nota registrarNota(@RequestBody Nota nota) {
        double promedio = (nota.getNota1() + nota.getNota2() + nota.getNota3()) / 3;
        nota.setPromedio(promedio);

        Estudiante est = estudianteRepo.findById(nota.getEstudiante().getId())
                .orElseThrow(() -> new RuntimeException("Estudiante no encontrado"));
        Curso curso = cursoRepo.findById(nota.getCurso().getId())
                .orElseThrow(() -> new RuntimeException("Curso no encontrado"));

        nota.setEstudiante(est);
        nota.setCurso(curso);

        return notaRepo.save(nota);
    }

    // Listar notas de un curso
    @GetMapping("/curso/{cursoId}")
    public List<Nota> listarNotasPorCurso(@PathVariable Long cursoId) {
        return notaRepo.findAll().stream()
                .filter(n -> n.getCurso().getId() == cursoId)
                .toList();
    }

    // Listar notas de un estudiante
    @GetMapping("/estudiante/{estudianteId}")
    public List<Nota> listarNotasPorEstudiante(@PathVariable Long estudianteId) {
        return notaRepo.findAll().stream()
                .filter(n -> n.getEstudiante().getId() == estudianteId)
                .toList();
    }




}
