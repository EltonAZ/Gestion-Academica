package com.colegio.colegio.controller;

import com.colegio.colegio.entity.Usuario;
import com.colegio.colegio.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/usuarios")//Permite la llamada de tu fronted
public class UsuarioController {
    @Autowired
    private UsuarioRepository usuarioRepo;

    // Listar todos los usuarios
    @GetMapping
    public List<Usuario> listar() {
        return usuarioRepo.findAll();
    }

    // Registrar un nuevo usuario
    @PostMapping
    public Usuario registrar(@RequestBody Usuario usuario) {
        return usuarioRepo.save(usuario);
    }

    // Actualizar usuario
    @PutMapping("/{id}")
    public Usuario actualizar(@PathVariable Long id, @RequestBody Usuario usuario) {
        usuario.setId(id);
        return usuarioRepo.save(usuario);
    }


    // Login
    // Eliminar usuario
    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable Long id) {
        usuarioRepo.deleteById(id);
    }

}
